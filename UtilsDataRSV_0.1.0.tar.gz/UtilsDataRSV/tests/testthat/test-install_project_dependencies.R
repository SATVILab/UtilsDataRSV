test_that("install_project_dependencies works", {
  y <- install_project_dependencies()
})
